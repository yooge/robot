var tools = require('robot-tools');
 
var argv = process.argv; 
 
if(argv[2]=='deploy'){
  tools.deploy();
}
if(argv[2]=='init'){ 
  tools.installapk();
}