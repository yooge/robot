console.log('I am remote script');
toast('I am remote script');
